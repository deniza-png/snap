# Uploading to GitHub

## Browser upload

1. Extract this package.
2. Create a repository on GitHub. Suggested name: `meet-vanish`.
3. Choose public or private visibility. Do not auto-generate a README or license: this package already has a README, and the first-party license has not been chosen.
4. Choose **Add file → Upload files** and upload the **contents** of the extracted `meet-vanish` folder. Do not upload just the ZIP, or wrap everything in another `meet-vanish` folder.
5. Confirm the repository root contains `README.md`, `package.json`, and `meet-vanish-extension/`, then commit.

The folder contains hidden `.github/` and `.gitignore` entries. Enable hidden-file visibility before uploading and check they appear in the repository. If browser upload does not preserve the hidden workflow folder, use Git instead.

The repository contains about 28 MB of extension files. Each bundled file is below GitHub's browser-upload per-file limit of 25 MiB. Git LFS is not needed for this package.

## Upload with Git (recommended)

Open a terminal in the extracted `meet-vanish` folder. Replace the example URL with your new repository URL:

```sh
git init
git add .
git commit -m "Add Meet Vanish v1.7.2"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/meet-vanish.git
git push -u origin main
```

Use GitHub's normal authentication flow; never put a token in a file or commit it.

## Make an installable release

1. Run `npm test` and `python3 scripts/package-release.py`.
2. On GitHub, open **Releases → Draft a new release**.
3. Create tag `v1.7.2` on the uploaded commit.
4. Use title **Meet Vanish v1.7.2**.
5. Attach both files from `dist/`: the extension ZIP and its `.sha256` sidecar.
6. Mention that installation uses **Load unpacked** in Chrome and the release supports Google Meet only.
7. Review visibility and licensing, then publish.

Alternatively, download the extension artifact from a successful Actions run, extract the artifact wrapper, and attach the inner extension ZIP and checksum to the release.

Creating/publishing the repository and release is up to you; this package does not upload anything automatically.
